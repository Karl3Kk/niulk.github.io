from django.apps import AppConfig


class JssdkConfig(AppConfig):
    name = 'jssdk'
