# wxApi
用于获取jsapi_ticket，算法生成签名，微信分享链接定义缩略图，标题，描述
